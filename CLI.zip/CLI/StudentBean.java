class StudentBean
{
  public int rollNumber;
  public String studentName;
  public String degree;

  StudentBean(int rollNumber,String studentName,String degree)
  {
      this.rollNumber = rollNumber;
      this.studentName = studentName;
      this.degree = degree;
  }   
}
