@RestController
class WebApplication
{
   @RequestMapping("/")
   private String getMyGreetings()
   {
     return "Welcome to TutorialsPoint.Com";
   }
}
